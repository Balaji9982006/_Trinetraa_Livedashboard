import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Power } from "lucide-react";
import spliceImg from "@/assets/splice.jpg.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Predbelt – Intelligent Conveyor Belt Digital Twin" },
      { name: "description", content: "Smart conveyor monitoring with power control, temperature and sound sensing." },
      { property: "og:title", content: "Predbelt – Intelligent Conveyor Belt Digital Twin" },
      { property: "og:description", content: "Smart conveyor monitoring with power control, temperature and sound sensing." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

type Item = { id: number; pos: number; defect: boolean; scanned: boolean; size: number; splice?: boolean; cut?: "edge" | "center" | undefined };
type Log = { t: string; msg: string; kind: "info" | "edge" | "cloud" };
type Load = "low" | "normal" | "high" | "none";

function Index() {
  const [power, setPower] = useState(false);
  const [running, setRunning] = useState(false);
  const [load, setLoad] = useState<Load>("normal");
  const [items, setItems] = useState<Item[]>([]);
  const [offset, setOffset] = useState(0);
  const [defect, setDefect] = useState(false);
  const [temp, setTemp] = useState(28);
  const [sound, setSound] = useState(20);
  const [logs, setLogs] = useState<Log[]>([{ t: "", msg: "System initialized. Power is OFF.", kind: "info" }]);
  const beltRef = useRef<HTMLDivElement>(null);
  const logRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(0);
  const spawnRef = useRef(0);
  const st = useRef({ running, load, power, defect });
  st.current = { running, load, power, defect };

  const log = (msg: string, kind: Log["kind"] = "info") =>
    setLogs((l) => [...l.slice(-80), { t: new Date().toLocaleTimeString(), msg, kind }]);

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight });
  }, [logs]);

  // belt animation
  useEffect(() => {
    let raf = 0;
    const tick = () => {
      const { running, load } = st.current;
      if (running) {
        setOffset((o) => o + 1);
        const w = beltRef.current?.clientWidth ?? 800;
        const cam = w * 0.7;
        spawnRef.current++;
        const th = load === "high" ? 40 : load === "low" ? 120 : 80;
        let spawn: Item | null = null;
        if (load !== "none" && spawnRef.current > th) {
          spawnRef.current = 0;
          spawn = { id: idRef.current++, pos: -20, defect: false, scanned: false, size: load === "high" ? 30 : load === "low" ? 14 : 22 };
        }
        setItems((prev) => {
          const next = (spawn ? [...prev, spawn] : prev)
            .map((it) => ({ ...it, pos: it.pos + 1 }))
            .filter((it) => it.pos < w + 20);
          next.forEach((it) => {
            if (!it.scanned && it.pos >= cam) {
              it.scanned = true;
              if (it.defect) {
                const name = it.splice ? "Splice open" : it.cut === "edge" ? "Edge cut" : "Center cut";
                setTimeout(() => {
                  setDefect(true);
                  log(`EDGE AI: ${name} detected at 7m mark!`, "edge");
                  log("CLOUD ALERT: Maintenance ticket raised. Belt halted.", "cloud");
                  setRunning(false);
                }, 0);
              }
            }
          });
          return next;
        });
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  // sensors
  useEffect(() => {
    const iv = setInterval(() => {
      const { running, load, power, defect } = st.current;
      const lf = load === "high" ? 1.4 : load === "low" ? 0.7 : load === "none" ? 0.4 : 1;
      const tTarget = !power ? 26 : running ? 40 + 15 * lf + (defect ? 20 : 0) : 32;
      const sTarget = !power ? 5 : running ? 45 + 20 * lf + (defect ? 25 : 0) : 15;
      setTemp((t) => +(t + (tTarget - t) * 0.025 + (Math.random() - 0.5) * 0.3).toFixed(1));
      setSound((s) => Math.max(0, +(s + (sTarget - s) * 0.06 + (Math.random() - 0.5) * 2).toFixed(0)));
    }, 600);
    return () => clearInterval(iv);
  }, []);

  const togglePower = (on: boolean) => {
    if (on === power) return;
    setPower(on);
    if (!on) setRunning(false);
    log(on ? "Main power supply: ON" : "Main power supply: OFF — motor de-energized", on ? "edge" : "info");
  };
  const start = () => {
    if (!power) return log("Cannot start: power supply is OFF.", "cloud");
    if (defect) return log("Cannot start: clear defect first (Reset).", "cloud");
    if (!running) { setRunning(true); log("Conveyor motor: STARTED"); }
  };
  const stop = () => { if (running) { setRunning(false); log("Conveyor motor: STOPPED"); } };
  const changeLoad = (l: Load) => {
    setLoad(l);
    if (l === "none") setItems((p) => p.filter((i) => i.defect));
    log(`Load profile changed to: ${l.toUpperCase()}`);
  };
  const [defectMenu, setDefectMenu] = useState(false);
  const injectDefect = (kind: "splice" | "edge" | "center") => {
    setItems((p) => [...p, { id: idRef.current++, pos: -20, defect: true, scanned: false, size: kind === "splice" ? 28 : 24, splice: kind === "splice", cut: kind === "splice" ? undefined : kind }]);
    log(`SIMULATION: ${kind === "splice" ? "Splice open" : kind === "edge" ? "Edge cut" : "Center cut"} injected at 0m mark.`);
  };
  const reset = () => {
    setRunning(false); setItems([]); setDefect(false); setLoad("normal"); setOffset(0);
    setLogs([{ t: new Date().toLocaleTimeString(), msg: "System reset. Edge and cloud flags cleared.", kind: "info" }]);
  };

  const tempPct = Math.min(100, Math.max(0, ((temp - 20) / 80) * 100));
  const soundPct = Math.min(100, sound);
  const tempState = temp > 75 ? "Critical" : temp > 55 ? "Warm" : "Normal";
  const soundState = sound > 85 ? "Abnormal" : sound > 65 ? "Elevated" : "Normal";

  const btn = "rounded-lg px-3 py-2.5 text-sm font-semibold transition disabled:opacity-40";

  return (
    <main className="min-h-screen bg-background px-4 py-8 text-foreground">
      <header className="mx-auto mb-6 max-w-6xl text-center">
        <h1 className="text-2xl font-bold text-primary md:text-3xl">Predbelt: Intelligent Conveyor Belt</h1>
        <p className="mt-1 text-sm text-muted-foreground">Problem Statement ID: 26008 · Smart Monitoring & Predictive Maintenance</p>
      </header>

      <div className="mx-auto grid max-w-6xl gap-5 lg:grid-cols-[1fr_320px]">
        <div className="space-y-5">
          {/* Belt */}
          <section className="rounded-2xl border bg-card p-5 shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className={`font-bold ${defect ? "text-destructive" : "text-success"}`}>
                {defect ? "● STATUS: DEFECT DETECTED – belt halted" : "● STATUS: HEALTHY (No defects found)"}
              </span>
              <span className="flex gap-2 text-xs">
                <Pill on={power} label={power ? "POWER ON" : "POWER OFF"} />
                <Pill on={running} label={running ? "RUNNING" : "IDLE"} />
              </span>
            </div>

            <h4 className="mt-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Physical Conveyor Belt</h4>
            <div className="relative mt-16 mb-8">
              <div className="absolute -top-14 left-[70%] z-10 flex -translate-x-1/2 flex-col items-center">
                <div className="rounded-md bg-primary px-2 py-1 text-xs font-bold text-primary-foreground shadow">📷 AI</div>
                <div className="h-20 w-0.5 bg-primary/50" />
              </div>
              <div className="belt-stage"><div className="belt-3d">
              <div
                ref={beltRef}
                className={`belt belt-solid relative h-24 rounded-md border-y-4 transition-colors ${defect ? "border-destructive" : power ? "border-success" : "border-muted-foreground/40"}`}
                style={{ backgroundPosition: `${offset * 2}px 0` }}
              >
                {items.map((it) => (
                  <span key={it.id} className="absolute drop-shadow-lg" style={{ top: it.cut === "edge" ? "18%" : "50%", left: it.pos, fontSize: it.size, transform: "translateY(-80%) rotateX(-55deg)", transformOrigin: "bottom" }}>
                    {it.splice ? <img src={spliceImg.url} alt="Broken splice" className="h-8 w-6 rounded object-contain" /> : it.defect ? "✂️" : "🪨"}
                  </span>
                ))}
              </div>
              </div></div>
              <div className="mt-2 flex justify-between px-2 text-xs text-muted-foreground">
                {[0, 2, 4, 6, 8, 10].map((m) => <span key={m}>{m}m</span>)}
              </div>
            </div>

            <div className="neon-zone mt-4 rounded-2xl p-4">
              <div className="flex items-center justify-between">
                <h4 className="neon-text text-xs font-bold uppercase tracking-wider">Digital Twin (Virtual Replica)</h4>
                <span className="neon-chip rounded-full px-2.5 py-1 text-[11px] font-semibold">⟳ Synced live</span>
              </div>
              <div className="relative mt-16 mb-2">
                <div className="absolute -top-14 left-[70%] z-10 flex -translate-x-1/2 flex-col items-center">
                  <div className="neon-chip rounded-md px-2 py-1 text-xs font-bold">📷 AI</div>
                  <div className="neon-line h-20 w-0.5" />
                </div>
                <div className="belt-stage"><div className="belt-3d">
                  <div
                    className={`neon-belt belt-neon relative h-24 rounded-md border-y-4 border-dotted ${defect ? "neon-fault" : ""}`}
                    style={{ backgroundPosition: `${offset * 2}px 0` }}
                  >
                    {items.map((it) => (
                      <span key={it.id} style={{ top: it.cut === "edge" ? "18%" : "50%", left: it.pos, fontSize: it.size, transform: "translateY(-80%) rotateX(-55deg)", transformOrigin: "bottom" }} className={`absolute ${it.defect ? "neon-item-bad animate-pulse" : "neon-item"}`}>
                        {it.splice ? <img src={spliceImg.url} alt="Broken splice (twin)" className="h-8 w-6 rounded object-contain" /> : it.defect ? "✂️" : "🪨"}
                      </span>
                    ))}
                  </div>
                </div></div>
                <div className="neon-text mt-2 flex justify-between px-2 font-mono text-[10px]">
                  {[0, 2, 4, 6, 8, 10].map((m) => <span key={m}>{m}.0m</span>)}
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2 text-center font-mono text-[11px]">
                  <div className="neon-chip rounded p-1.5">Objects: {items.length}</div>
                  <div className="neon-chip rounded p-1.5">Speed: {running ? "1.0" : "0.0"} m/s</div>
                  <div className={`rounded p-1.5 ${defect ? "neon-fault-chip" : "neon-chip"}`}>Faults: {items.filter((i) => i.defect).length}</div>
                </div>
              </div>
            </div>

            <div className="mt-5">
              <h4 className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">Detection Accuracy</h4>
              <div className="grid gap-3 sm:grid-cols-3">
                <Accuracy label="Physical Belt" value={65} note="Affected by dust, vibration, lighting & mechanical wear" tone="warning" />
                <Accuracy label="Digital Twin" value={95} note="Direct digital sensor data — highly reliable" tone="success" />
                <div className="rounded-xl border bg-card p-4 text-center">
                  <div className="text-xs font-semibold text-muted-foreground">Accuracy Ratio</div>
                  <div className="my-1 text-3xl font-bold text-primary">65 : 95</div>
                  <div className="text-xs text-muted-foreground">Twin is <b className="text-success">+30%</b> more accurate (≈1.46×)</div>
                </div>
              </div>
            </div>
          </section>

          {/* New block: power + sensors */}
          <section className="grid gap-4 md:grid-cols-3">
            <div className="rounded-2xl border bg-card p-5 shadow-sm">
              <h3 className="text-sm font-semibold text-muted-foreground">Power Supply</h3>
              <div className="my-4 flex items-center justify-center">
                <div className={`flex h-16 w-16 items-center justify-center rounded-full text-2xl transition ${power ? "bg-success/15 text-success ring-4 ring-success/30" : "bg-muted text-muted-foreground"}`}><Power className="h-8 w-8" strokeWidth={2.5} /></div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => togglePower(true)} className={`${btn} inline-flex items-center justify-center gap-1 ${power ? "bg-success text-primary-foreground" : "bg-success/15 text-success hover:bg-success/25"}`}><Power className="h-4 w-4" /> ON</button>
                <button onClick={() => togglePower(false)} className={`${btn} inline-flex items-center justify-center gap-1 ${!power ? "bg-destructive text-primary-foreground" : "bg-destructive/15 text-destructive hover:bg-destructive/25"}`}><Power className="h-4 w-4" /> OFF</button>
              </div>
            </div>
            <Meter title="Belt Temperature" value={`${temp.toFixed(1)} °C`} pct={tempPct} cls="meter-temp" state={tempState} danger={temp > 75} scale={["20°", "60°", "100°"]} />
            <Meter title="Sound Detection" value={`${sound} dB`} pct={soundPct} cls="meter-sound" state={soundState} danger={sound > 85} scale={["0", "50", "100 dB"]} />
          </section>

          <ProcessDiagram power={power} running={running} defect={defect} load={load} />

          {/* Controls */}
          <section className="rounded-2xl border bg-card p-5 shadow-sm">
            <h3 className="mb-3 border-b pb-2 font-semibold">Twin Controls</h3>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={start} disabled={!power} className={`${btn} bg-success text-primary-foreground hover:opacity-90`}>▶ Start Conveyor</button>
              <button onClick={stop} disabled={!running} className={`${btn} bg-destructive text-primary-foreground hover:opacity-90`}>⏸ Stop Conveyor</button>
              <button onClick={() => changeLoad("low")} className={`${btn} bg-secondary hover:bg-accent ${load === "low" ? "ring-2 ring-primary" : ""}`}>⬇ Low Load</button>
              <button onClick={() => changeLoad("high")} className={`${btn} bg-secondary hover:bg-accent ${load === "high" ? "ring-2 ring-primary" : ""}`}>⬆ High Load</button>
              <button onClick={() => changeLoad("none")} className={`${btn} bg-secondary hover:bg-accent ${load === "none" ? "ring-2 ring-primary" : ""}`}>🗑 Remove Load</button>
              <button onClick={() => changeLoad("normal")} className={`${btn} bg-secondary hover:bg-accent ${load === "normal" ? "ring-2 ring-primary" : ""}`}>♻ Normal Load</button>
              <button onClick={() => setDefectMenu((v) => !v)} aria-expanded={defectMenu} className={`${btn} col-span-2 bg-warning text-primary-foreground hover:opacity-90`}>⚠ Inject Defect {defectMenu ? "▲" : "▼"}</button>
              {defectMenu && (
                <div className="col-span-2 grid grid-cols-3 gap-2 rounded-lg border-l-4 border-warning bg-warning/10 p-2 animate-fade-in">
                  <button onClick={() => injectDefect("splice")} className={`${btn} inline-flex flex-col items-center gap-1 bg-card text-destructive ring-1 ring-destructive/40 hover:bg-destructive/10`}>
                    <img src={spliceImg.url} alt="" className="h-8 w-6 rounded object-contain" /> Splice Open
                  </button>
                  <button onClick={() => injectDefect("edge")} className={`${btn} inline-flex flex-col items-center gap-1 bg-card text-destructive ring-1 ring-destructive/40 hover:bg-destructive/10`}>
                    <span className="text-2xl">↗✂️</span> Edge Cut
                  </button>
                  <button onClick={() => injectDefect("center")} className={`${btn} inline-flex flex-col items-center gap-1 bg-card text-destructive ring-1 ring-destructive/40 hover:bg-destructive/10`}>
                    <span className="text-2xl">✂️</span> Center Cut
                  </button>
                </div>
              )}
              <button onClick={reset} className={`${btn} col-span-2 bg-muted-foreground text-primary-foreground hover:opacity-90`}>🔄 Reset System</button>
            </div>
          </section>
        </div>

        <aside className="rounded-2xl border bg-card p-5 shadow-sm">
          <h3 className="mb-3 font-semibold">System Telemetry Logs</h3>
          <div ref={logRef} className="flex h-[520px] flex-col gap-1.5 overflow-y-auto rounded-lg border bg-muted/40 p-2 font-mono text-xs">
            {logs.map((l, i) => (
              <div key={i} className={`rounded border-l-4 px-2 py-1 ${l.kind === "edge" ? "border-success bg-success/10" : l.kind === "cloud" ? "border-destructive bg-destructive/10 font-bold text-destructive" : "border-primary bg-primary/10"}`}>
                {l.t && `[${l.t}] `}{l.msg}
              </div>
            ))}
          </div>
        </aside>
      </div>
    </main>
  );
}

function Pill({ on, label }: { on: boolean; label: string }) {
  return <span className={`rounded-full px-2.5 py-1 font-semibold ${on ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"}`}>{label}</span>;
}

function Meter({ title, value, pct, cls, state, danger, scale }: { title: string; value: string; pct: number; cls: string; state: string; danger: boolean; scale: string[] }) {
  return (
    <div className="rounded-2xl border bg-card p-5 shadow-sm">
      <h3 className="text-sm font-semibold text-muted-foreground">{title}</h3>
      <div className={`my-3 text-3xl font-bold tabular-nums ${danger ? "text-destructive" : ""}`}>{value}</div>
      <div className="relative h-3 overflow-hidden rounded-full bg-muted">
        <div className={`${cls} h-full`} style={{ clipPath: `inset(0 ${100 - pct}% 0 0)`, transition: "clip-path .5s" }} />
      </div>
      <div className="mt-1 flex justify-between text-[10px] text-muted-foreground">{scale.map((s) => <span key={s}>{s}</span>)}</div>
      <div className={`mt-2 text-xs font-semibold ${danger ? "text-destructive" : state === "Normal" ? "text-success" : "text-warning"}`}>● {state}</div>
    </div>
  );
}

function ProcessDiagram({ power, running, defect, load }: { power: boolean; running: boolean; defect: boolean; load: Load }) {
  const steps = [
    { icon: "🔌", title: "Power Supply", sub: power ? "ON" : "OFF", active: power, bad: false },
    { icon: "⚙️", title: "Drive Motor", sub: running ? "Running" : "Idle", active: running, bad: false },
    { icon: "🪨", title: "Ore Loading", sub: `${load} load`, active: running && load !== "none", bad: false },
    { icon: "〰️", title: "Conveyor Belt", sub: "0–10 m", active: running, bad: defect },
    { icon: "🌡️", title: "Sensors", sub: "Temp + Sound", active: power, bad: false },
    { icon: "📷", title: "AI Camera", sub: "7 m mark", active: running, bad: defect },
    { icon: "🧠", title: "Edge Processing", sub: defect ? "Defect found" : "Analyzing", active: running || defect, bad: defect },
    { icon: "☁️", title: "Cloud & Alerts (Future Integration)", sub: defect ? "Alert raised" : "Logging", active: power, bad: defect },
  ];
  return (
    <section className="rounded-2xl border bg-card p-5 shadow-sm">
      <h3 className="mb-4 border-b pb-2 font-semibold">Process Block Diagram</h3>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {steps.map((s, i) => (
          <div key={s.title} className="relative">
            <div className={`flex h-full flex-col items-center rounded-xl border-2 p-3 text-center transition ${s.bad ? "border-destructive bg-destructive/10" : s.active ? "border-success bg-success/10" : "border-border bg-muted/40"}`}>
              <span className="text-2xl">{s.icon}</span>
              <span className="mt-1 text-xs font-bold">{i + 1}. {s.title}</span>
              <span className={`text-[11px] capitalize ${s.bad ? "text-destructive" : "text-muted-foreground"}`}>{s.sub}</span>
            </div>
            {i < steps.length - 1 && (
              <span className={`absolute top-1/2 -right-3 z-10 hidden -translate-y-1/2 text-primary sm:block ${i === 3 ? "sm:hidden" : ""}`}>→</span>
            )}
          </div>
        ))}
      </div>
      <p className="mt-3 text-xs text-muted-foreground">Flow: Power → Motor → Loading → Belt → Sensors & Camera → Edge AI → Cloud alerts. Green = active, red = fault.</p>
    </section>
  );
}

function Accuracy({ label, value, note, tone }: { label: string; value: number; note: string; tone: "warning" | "success" }) {
  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="flex items-baseline justify-between">
        <span className="text-xs font-semibold text-muted-foreground">{label}</span>
        <span className={`text-3xl font-bold ${tone === "success" ? "text-success" : "text-warning"}`}>{value}%</span>
      </div>
      <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-muted">
        <div className={`h-full rounded-full ${tone === "success" ? "bg-success" : "bg-warning"}`} style={{ width: `${value}%` }} />
      </div>
      <p className="mt-2 text-[11px] text-muted-foreground">{note}</p>
    </div>
  );
}
